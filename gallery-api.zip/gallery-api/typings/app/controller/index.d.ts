// This file is created by egg-ts-helper@1.25.2
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportHome = require('../../../app/controller/home');
import ExportMGallery = require('../../../app/controller/m/gallery');
import ExportManagerPhoto = require('../../../app/controller/manager/photo');

declare module 'egg' {
  interface IController {
    home: ExportHome;
    m: {
      gallery: ExportMGallery;
    }
    manager: {
      photo: ExportManagerPhoto;
    }
  }
}
