// This file is created by egg-ts-helper@1.25.2
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportGallery = require('../../../app/service/gallery');

declare module 'egg' {
  interface IService {
    gallery: ExportGallery;
  }
}
